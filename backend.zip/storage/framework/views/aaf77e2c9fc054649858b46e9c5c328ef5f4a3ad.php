<div class="card-header">
    <img
      class="logo-img"
      src="<?php echo e(asset("images/logo.jpeg")); ?>"
      alt="Hire and Pass"
    />
  </div>
<?php /**PATH C:\xampp\htdocs\SBSC\tmds\resources\views/layouts/mail/header.blade.php ENDPATH**/ ?>
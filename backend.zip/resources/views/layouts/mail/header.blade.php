<div class="card-header">
    <img class="logo-img" src="{{ asset('images/TourismLogo.png') }}" alt="Hire and Pass" />
</div>

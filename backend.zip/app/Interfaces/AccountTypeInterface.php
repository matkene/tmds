<?php

namespace App\Interfaces;

interface AccountTypeInterface {
    const INDIVIDUAL = 'Individual';
    const BUSINESS = 'Business';
}

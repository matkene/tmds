<?php

namespace App\Interfaces;

interface RoleInterface {
    const USER = 1;
    const DEVELOPER = 3;
    const ADMIN = 2;
}

<?php

namespace App\Interfaces;

interface BookingTypeInterface {
    const ONLINE_BOOKING = 'Online Booking';
    const IN_PERSON = 'In Person Booking';
}

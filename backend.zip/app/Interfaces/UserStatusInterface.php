<?php

namespace App\Interfaces;

interface UserStatusInterface {
    const ACTIVE = 1;
    const INACTIVE = 0;
}

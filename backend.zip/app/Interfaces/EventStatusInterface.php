<?php

namespace App\Interfaces;

interface EventStatusInterface {
    const UPCOMING = 'Upcoming';
    const ONGOING = 'Ongoing';
    const PAST = 'Past';
}


<?php

return [
    'base_url' => env('PAYMENT_BASE_URL'),
    'username' => env('PAYMENT_USERNAME'),
    'password' => env('PAYMENT_PASSWORD'),
];
